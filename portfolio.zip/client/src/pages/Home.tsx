import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Mail, Github, Linkedin, ExternalLink, ArrowRight, Code, Database, Zap, BookOpen, CheckCircle, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import emailjs from "@emailjs/browser";

/**
 * Design Philosophy: Minimalist Glassmorphism
 * - Clean, professional aesthetic with deep navy accents and soft purple gradients
 * - Glassmorphic cards with subtle hover effects
 * - Asymmetric layouts with generous whitespace
 * - Smooth scroll animations and purposeful micro-interactions
 * 
 * EmailJS Integration:
 * - Service ID: service_h1ku6qr
 * - Template ID: template_3vp5far
 * - Public Key: 4icNXapR3rA8umSAj
 */

// Initialize EmailJS
emailjs.init("4icNXapR3rA8umSAj");

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [isLoading, setIsLoading] = useState(false);
  const [formStatus, setFormStatus] = useState<"idle" | "success" | "error">("idle");
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Clear status message after 5 seconds
  useEffect(() => {
    if (formStatus !== "idle") {
      const timer = setTimeout(() => setFormStatus("idle"), 5000);
      return () => clearTimeout(timer);
    }
  }, [formStatus]);

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.name.trim()) {
      errors.name = "Name is required";
    }

    if (!formData.email.trim()) {
      errors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Please enter a valid email address";
    }

    if (!formData.subject.trim()) {
      errors.subject = "Subject is required";
    }

    if (!formData.message.trim()) {
      errors.message = "Message is required";
    } else if (formData.message.trim().length < 10) {
      errors.message = "Message must be at least 10 characters long";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error for this field when user starts typing
    if (formErrors[name]) {
      setFormErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Send email using EmailJS
      await emailjs.send("service_h1ku6qr", "template_3vp5far", {
        to_email: "dikshahooda@648gmail.com",
        from_name: formData.name,
        from_email: formData.email,
        subject: formData.subject,
        message: formData.message,
      });

      // Success
      setFormStatus("success");
      setFormData({ name: "", email: "", subject: "", message: "" });
    } catch (error) {
      console.error("EmailJS error:", error);
      setFormStatus("error");
    } finally {
      setIsLoading(false);
    }
  };

  const skills = [
    { icon: Code, title: "Frontend Development", description: "React, TypeScript, Tailwind CSS, responsive design" },
    { icon: Database, title: "Backend Development", description: "Node.js, Python, SQL, REST APIs, databases" },
    { icon: Zap, title: "Full Stack", description: "End-to-end development, system design, optimization" },
    { icon: BookOpen, title: "Problem Solving", description: "Algorithms, data structures, competitive programming" },
  ];

  const projects = [
    {
      title: "AI-Powered Chat Application",
      description: "Real-time chat application with AI assistance, built with React and Node.js. Features include user authentication, message persistence, and AI-powered responses.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663750181953/QoF82vFRYpaGyBFe5CS8PY/tech-abstract-1-HpptWEMbLLYHbt27PoUDwB.webp",
      tags: ["React", "Node.js", "WebSocket", "AI"],
      link: "#",
    },
    {
      title: "E-Commerce Platform",
      description: "Full-stack e-commerce solution with product catalog, shopping cart, and payment integration. Responsive design for mobile and desktop.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663750181953/QoF82vFRYpaGyBFe5CS8PY/tech-abstract-2-447g888hSFXhiwbWvNTv6T.webp",
      tags: ["React", "Stripe", "PostgreSQL", "Express"],
      link: "#",
    },
    {
      title: "Data Visualization Dashboard",
      description: "Interactive dashboard for visualizing complex datasets with real-time updates. Built with React and D3.js for advanced charting capabilities.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663750181953/QoF82vFRYpaGyBFe5CS8PY/tech-abstract-3-9D5LbWzqWGV2oGjHX7oMDQ.webp",
      tags: ["React", "D3.js", "TypeScript", "WebGL"],
      link: "#",
    },
    {
      title: "Cloud Infrastructure Manager",
      description: "Tool for managing cloud resources across multiple providers. Features include resource monitoring, cost analysis, and automated scaling.",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663750181953/QoF82vFRYpaGyBFe5CS8PY/tech-abstract-4-DwrUTq4dxr9udD3pZfFxg6.webp",
      tags: ["Python", "AWS", "Kubernetes", "React"],
      link: "#",
    },
  ];

  const education = [
    {
      degree: "Bachelor of Science in Computer Science",
      school: "Indira Gandhi Delhi Technical University for Women (IGDTUW)",
      year: "1st Year",
      details: "CGA: 7.99/10 | Location: Delhi, India | Relevant Coursework: Data Structures, Algorithms, Database Systems, Web Development",
    },
    {
      degree: "Senior Secondary (11-12)",
      school: "BVM Model School",
      year: "2024",
      details: "Percentage: 80% | Strong foundation in Mathematics, Physics, and Computer Science",
    },
    {
      degree: "Secondary (10)",
      school: "Vikas Bharti School",
      year: "2022",
      details: "Percentage: 89% | Excellent performance in core subjects and competitive exams",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 glass">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="font-display text-2xl font-bold gradient-text">Portfolio</h1>
          <div className="hidden md:flex gap-8">
            <a href="#about" className="text-foreground hover:text-[#7c5cdb] transition-colors">About</a>
            <a href="#skills" className="text-foreground hover:text-[#7c5cdb] transition-colors">Skills</a>
            <a href="#projects" className="text-foreground hover:text-[#7c5cdb] transition-colors">Projects</a>
            <a href="#education" className="text-foreground hover:text-[#7c5cdb] transition-colors">Education</a>
            <a href="#contact" className="text-foreground hover:text-[#7c5cdb] transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-32 md:pt-32 md:pb-48">
        <div
          className="absolute inset-0 z-0 opacity-40"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663750181953/QoF82vFRYpaGyBFe5CS8PY/hero-gradient-bg-Ec2hTyUf9xFiBqcLjzPMo3.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-down">
              <h2 className="font-display text-5xl md:text-6xl font-bold text-[#1a3a52] mb-6 leading-tight">
                Hello, I'm <span className="gradient-text">Diksha Hooda</span>
              </h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                First-year Computer Science student at IGDTUW, passionate about building elegant, performant web applications and solving complex problems through code. I specialize in full-stack development with a focus on user experience and clean architecture.
              </p>
              <div className="flex gap-4">
                <Button className="bg-[#1a3a52] hover:bg-[#0f1f2e] text-white px-8 py-6 text-lg rounded-lg transition-all duration-300 hover:shadow-lg">
                  View My Work <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button variant="outline" className="border-[#7c5cdb] text-[#7c5cdb] hover:bg-[#f3f0ff] px-8 py-6 text-lg rounded-lg transition-all duration-300">
                  Download CV
                </Button>
              </div>
            </div>
            <div className="hidden md:block animate-fade-in-up">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-[#7c5cdb] to-[#1a3a52] rounded-2xl blur-2xl opacity-20" />
                <img
                  src="/manus-storage/Screenshot2026-05-31205212_ddbca4bd.png"
                  alt="Diksha Hooda"
                  className="relative rounded-2xl shadow-2xl object-cover w-full h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 md:py-32 gradient-bg">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h3 className="font-display text-4xl md:text-5xl font-bold text-[#1a3a52] mb-8 animate-fade-in-up">About Me</h3>
            <div className="glass glass-hover p-8 md:p-12 rounded-2xl">
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                I'm Diksha Hooda, a first-year Computer Science student at Indira Gandhi Delhi Technical University for Women (IGDTUW) in Delhi, India. With a CGA of 7.99, I'm passionate about creating beautiful, functional digital experiences and combining technical knowledge with creative problem-solving.
              </p>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                My journey in tech started with curiosity about how things work. Today, I'm proficient in full-stack development, cloud technologies, and emerging AI applications. I believe in writing clean, maintainable code and designing interfaces that users love.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                When I'm not coding, you'll find me exploring new technologies, contributing to open-source projects, or sharing knowledge with the developer community. I'm excited to grow as a developer and make meaningful contributions to the tech industry.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 md:py-32 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="font-display text-4xl md:text-5xl font-bold text-[#1a3a52] mb-16 text-center animate-fade-in-up">
            Core Skills
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {skills.map((skill, index) => {
              const Icon = skill.icon;
              return (
                <div
                  key={index}
                  className="glass glass-hover p-8 rounded-xl text-center transition-all duration-300 hover:shadow-xl"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="mb-4 flex justify-center">
                    <div className="p-3 bg-gradient-to-br from-[#7c5cdb] to-[#1a3a52] rounded-lg">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <h4 className="font-display text-xl font-bold text-[#1a3a52] mb-3">{skill.title}</h4>
                  <p className="text-gray-600 text-sm leading-relaxed">{skill.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 md:py-32 gradient-bg">
        <div className="container mx-auto px-4">
          <h3 className="font-display text-4xl md:text-5xl font-bold text-[#1a3a52] mb-16 text-center animate-fade-in-up">
            Featured Projects
          </h3>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <div
                key={index}
                className="glass glass-hover rounded-xl overflow-hidden transition-all duration-300 hover:shadow-2xl"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="relative h-48 overflow-hidden bg-gray-200">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <div className="p-6 md:p-8">
                  <h4 className="font-display text-2xl font-bold text-[#1a3a52] mb-3">{project.title}</h4>
                  <p className="text-gray-600 mb-4 leading-relaxed">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tags.map((tag, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 bg-[#f3f0ff] text-[#7c5cdb] text-sm rounded-full font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <a
                    href={project.link}
                    className="inline-flex items-center text-[#7c5cdb] hover:text-[#1a3a52] font-semibold transition-colors"
                  >
                    View Project <ExternalLink className="ml-2 w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 md:py-32 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="font-display text-4xl md:text-5xl font-bold text-[#1a3a52] mb-16 text-center animate-fade-in-up">
            Education & Certifications
          </h3>
          <div className="max-w-2xl mx-auto space-y-8">
            {education.map((item, index) => (
              <div
                key={index}
                className="glass glass-hover p-8 rounded-xl transition-all duration-300"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-display text-2xl font-bold text-[#1a3a52]">{item.degree}</h4>
                    <p className="text-[#7c5cdb] font-semibold mt-1">{item.school}</p>
                  </div>
                  <span className="px-4 py-2 bg-[#f3f0ff] text-[#7c5cdb] rounded-full font-semibold text-sm">
                    {item.year}
                  </span>
                </div>
                <p className="text-gray-600">{item.details}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 md:py-32 gradient-bg">
        <div className="container mx-auto px-4">
          <h3 className="font-display text-4xl md:text-5xl font-bold text-[#1a3a52] mb-16 text-center animate-fade-in-up">
            Get In Touch
          </h3>
          <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
            {/* Contact Info */}
            <div className="space-y-8">
              <div className="glass glass-hover p-6 rounded-xl">
                <div className="flex items-center gap-4 mb-3">
                  <div className="p-3 bg-gradient-to-br from-[#7c5cdb] to-[#1a3a52] rounded-lg">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Email</p>
                    <a href="mailto:dikshahooda@648gmail.com" className="font-semibold text-[#1a3a52] hover:text-[#7c5cdb]">
                      dikshahooda@648gmail.com
                    </a>
                  </div>
                </div>
              </div>
              <div className="glass glass-hover p-6 rounded-xl">
                <div className="flex items-center gap-4 mb-3">
                  <div className="p-3 bg-gradient-to-br from-[#7c5cdb] to-[#1a3a52] rounded-lg">
                    <Github className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">GitHub</p>
                    <a href="https://github.com/dikshahooda648-debug" className="font-semibold text-[#1a3a52] hover:text-[#7c5cdb]">
                      github.com/dikshahooda648-debug
                    </a>
                  </div>
                </div>
              </div>
              <div className="glass glass-hover p-6 rounded-xl">
                <div className="flex items-center gap-4 mb-3">
                  <div className="p-3 bg-gradient-to-br from-[#7c5cdb] to-[#1a3a52] rounded-lg">
                    <Linkedin className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">LinkedIn</p>
                    <a href="https://www.linkedin.com/in/diksha-hooda-1192a8375/" className="font-semibold text-[#1a3a52] hover:text-[#7c5cdb]">
                      linkedin.com/in/diksha-hooda
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="glass glass-hover p-8 rounded-xl">
              {/* Success Message */}
              {formStatus === "success" && (
                <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3 animate-scale-in">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-green-900">Message sent successfully!</p>
                    <p className="text-sm text-green-700">Thank you for reaching out. I'll get back to you soon.</p>
                  </div>
                </div>
              )}

              {/* Error Message */}
              {formStatus === "error" && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3 animate-scale-in">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-red-900">Failed to send message</p>
                    <p className="text-sm text-red-700">Please try again or contact me directly.</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleFormSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-[#1a3a52] mb-2">
                    Name {formErrors.name && <span className="text-red-500">*</span>}
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleFormChange}
                    className={`w-full px-4 py-3 bg-white/50 border rounded-lg focus:outline-none focus:ring-2 transition-all ${
                      formErrors.name
                        ? "border-red-300 focus:ring-red-500"
                        : "border-white/30 focus:ring-[#7c5cdb]"
                    }`}
                    placeholder="e.g., Diksha Hooda"
                    disabled={isLoading}
                  />
                  {formErrors.name && <p className="text-red-600 text-sm mt-1">{formErrors.name}</p>}
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-[#1a3a52] mb-2">
                    Email {formErrors.email && <span className="text-red-500">*</span>}
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleFormChange}
                    className={`w-full px-4 py-3 bg-white/50 border rounded-lg focus:outline-none focus:ring-2 transition-all ${
                      formErrors.email
                        ? "border-red-300 focus:ring-red-500"
                        : "border-white/30 focus:ring-[#7c5cdb]"
                    }`}
                    placeholder="your.email@example.com"
                    disabled={isLoading}
                  />
                  {formErrors.email && <p className="text-red-600 text-sm mt-1">{formErrors.email}</p>}
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-semibold text-[#1a3a52] mb-2">
                    Subject {formErrors.subject && <span className="text-red-500">*</span>}
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleFormChange}
                    className={`w-full px-4 py-3 bg-white/50 border rounded-lg focus:outline-none focus:ring-2 transition-all ${
                      formErrors.subject
                        ? "border-red-300 focus:ring-red-500"
                        : "border-white/30 focus:ring-[#7c5cdb]"
                    }`}
                    placeholder="What is this about?"
                    disabled={isLoading}
                  />
                  {formErrors.subject && <p className="text-red-600 text-sm mt-1">{formErrors.subject}</p>}
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-[#1a3a52] mb-2">
                    Message {formErrors.message && <span className="text-red-500">*</span>}
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleFormChange}
                    rows={4}
                    className={`w-full px-4 py-3 bg-white/50 border rounded-lg focus:outline-none focus:ring-2 transition-all resize-none ${
                      formErrors.message
                        ? "border-red-300 focus:ring-red-500"
                        : "border-white/30 focus:ring-[#7c5cdb]"
                    }`}
                    placeholder="Your message..."
                    disabled={isLoading}
                  />
                  {formErrors.message && <p className="text-red-600 text-sm mt-1">{formErrors.message}</p>}
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-[#1a3a52] to-[#7c5cdb] hover:from-[#0f1f2e] hover:to-[#6b4bc9] text-white py-3 rounded-lg font-semibold transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      Sending...
                    </span>
                  ) : (
                    "Send Message"
                  )}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1a3a52] text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 mb-6 md:mb-0">
              © 2024 Diksha Hooda. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="https://github.com/dikshahooda648-debug" className="hover:text-[#7c5cdb] transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="https://www.linkedin.com/in/diksha-hooda-1192a8375/" className="hover:text-[#7c5cdb] transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="mailto:dikshahooda@648gmail.com" className="hover:text-[#7c5cdb] transition-colors">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
